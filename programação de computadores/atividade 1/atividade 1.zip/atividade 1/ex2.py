nome = str(input('Digite seu nome: '))
idade = str(input('Digite sua idade: '))
profissao = str(input('Digite sua profissão: '))

print (f'Olá seu nome é {nome}, sua idade é {idade} e sua profissão é {profissao}')
