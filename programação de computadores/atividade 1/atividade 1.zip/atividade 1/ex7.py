h = float(input('digite a hora: '))

m = h *60

print(f'a hora digitada em minutos fica {m}.')