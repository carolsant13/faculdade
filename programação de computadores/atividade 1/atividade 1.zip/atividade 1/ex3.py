conta = float(input('Valor gasto pelo cliente no restaurante ComaBem: '))

val = (conta* 0.10) + conta

print(f'valor final {val}')