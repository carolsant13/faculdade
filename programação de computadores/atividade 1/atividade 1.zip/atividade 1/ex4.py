import math

a = float(input('digite o valor de a: '))
b = float(input('digite o valor de b: '))
c = float(input('digite o valor de c: '))

delta = (b**2) - (4*a*c)

x = -b / (2*a)

x1 = (-b + math.sqrt(delta)) / (2*a)
x2 = (-b - math.sqrt(delta)) / (2*a)
print (f'as raizes da equação são: {x1}, {x2}')
