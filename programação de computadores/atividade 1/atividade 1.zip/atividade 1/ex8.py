idade = float(input('digite a sua idade em anos'))

m = idade * 12
d = idade * 365

print (f'sua idade em meses é {m} e sua idade em dias é {d}')