tc = float(input('digite a temperatura em graus Celsius para a conversão: '))

tk = tc + 273

tf = (1,8 * tc) + 32


print (f'temperatura em Kelvin {tk}, temperatura em Fahrenheit {tf}')