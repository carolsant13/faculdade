base = float (input('digite o valor da base do triângulo'))
altura = float (input('digite o valor da altura do triângulo'))

area = (base * altura) /2

print(f'a area do triangulo é {area}.')