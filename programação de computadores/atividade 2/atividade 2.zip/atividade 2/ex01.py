n1 = float (input('digite um valor: '))
n2 = float (input('digite outro valor: '))

r = n1%n2

print (f'a divisão inteira de {n1} por {n2} é {r}')