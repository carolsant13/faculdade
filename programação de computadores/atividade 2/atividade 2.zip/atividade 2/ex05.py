n1 = int(input('digite um valor: '))

if 0 <= n1 <= 9:
    print('valor correto')
else:
    print('valor incorreto')