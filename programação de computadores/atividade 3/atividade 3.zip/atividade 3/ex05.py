n = int(input('digite um valor inteiro: '))

for i in range (1, n):
    s += 1/i

print(f'o resultado da equação é: {s}')