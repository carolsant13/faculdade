for i in range (1, 51):
    print(i)
print('-------------------------------------------------')
for i in range (52, 101, 2):
    print(i)
