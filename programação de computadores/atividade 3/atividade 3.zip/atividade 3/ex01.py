n = int (input('digite um numero: '))

print(f'tabuada {n}: ')

for i in range(1, 11):
    r = n * i
    print(f"{n} X {i} = {r}")
